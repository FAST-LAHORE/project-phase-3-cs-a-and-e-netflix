/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netflix;

/**
 *
 * @author Faaiz
 */
public class incdec {
    public static int i=0,i2=3,i3=7;
    incdec(){
    }
        public static int givestart(){
            i++;
            return i; 
                    }
         public static int giveend(){
            i--;
            return i; 
                    }
        
         public static int givestart2(){
            i2++;
            return i2; 
                    }
         public static int giveend2(){
            i3--;
            return i3; 
                    }
        
         public static int givestart3(){
            i3++;
            return i3; 
                    }
         public static int giveend3(){
            i--;
            return i; 
                    }
        
    }
    
